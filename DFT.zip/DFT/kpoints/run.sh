#!/bin/bash
# Convergence test of Kpoints.

# Set K-points
for mesh in 4 5 6 7 8 9 10 11 12 13 14 15 16 ; do

cat > kpoints.$mesh.in << EOF
&CONTROL
 calculation='scf',
 outdir='.',
 prefix='NaCl',
 pseudo_dir    = '/home/max/pseudo',
 verbosity='low',
 tprnfor=.true.,
 tstress=.true.,
/
&SYSTEM
 ibrav = 0
 A = 3.4
 nat = 2
 ntyp = 2
 ecutwfc =60,
 ecutrho = 300,
 input_dft='pbe',
 occupations='smearing',
 smearing='mv',
 degauss=0.005d0,
/
&ELECTRONS
 conv_thr=1d-8,
 mixing_beta=0.7d0,
/
&IONS
 ion_dynamics='bfgs',
/
&CELL
 cell_dynamics='bfgs',
 press=0.d0,
 press_conv_thr=0.5d0,
/

CELL_PARAMETERS {alat}
 1.0 0.0 0.0
 0.0 1.0 0.0
 0.0 0.0 1.0

ATOMIC_SPECIES
 Cl 35.45150 cl_pbe_v1.4.uspp.F.UPF
 Na 22.98900 na_pbe_v1.5.uspp.F.UPF

ATOMIC_POSITIONS {crystal}
 Cl 0.5 0.5 0.5
 Na 0.0 0.0 0.0

K_POINTS {automatic}
${mesh} ${mesh} ${mesh} 0 0 0
EOF

# Run SCF
mpirun -np 4 pw.x < kpoints.$mesh.in > kpoints.$mesh.out

# Extract total stress
awk '/kbar/ { printf "%d %s\n", '"$mesh"', $6 }' kpoints.$mesh.out >> calc-kpoints.dat


done

