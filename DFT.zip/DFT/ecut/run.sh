#!/bin/bash
# Convergence test of cut-off energy.

# Set cutoffs
for ecut in 20 25 30 35 40 45 50 55 60 65 70 75 80; do

cat > ecut.$ecut.in << EOF
&CONTROL
 calculation='scf',
 outdir='.',
 prefix='NaCl',
 pseudo_dir    = '/home/max/pseudo',
 verbosity='low',
 tprnfor=.true.,
 tstress=.true.,
/
&SYSTEM
 ibrav = 0
 A = 3.4
 nat = 2
 ntyp = 2
 ecutwfc = ${ecut},
 ecutrho = 200,
 input_dft='pbe',
 occupations='smearing',
 smearing='mv',
 degauss=0.005d0,
/
&ELECTRONS
 conv_thr=1d-8,
 mixing_beta=0.7d0,
/
&IONS
 ion_dynamics='bfgs',
/
&CELL
 cell_dynamics='bfgs',
 press=0.d0,
 press_conv_thr=0.5d0,
/

CELL_PARAMETERS {alat}
 1.0 0.0 0.0
 0.0 1.0 0.0
 0.0 0.0 1.0

ATOMIC_SPECIES
 Cl 35.45150 cl_pbe_v1.4.uspp.F.UPF
 Na 22.98900 na_pbe_v1.5.uspp.F.UPF

ATOMIC_POSITIONS {crystal}
 Cl 0.5 0.5 0.5
 Na 0.0 0.0 0.0

K_POINTS {automatic}
 5 5 5 0 0 0
EOF

# Run SCF
mpirun -np 4 pw.x < ecut.$ecut.in > ecut.$ecut.out

# Extract total stress
awk "/kbar/ {printf \"%d %s\n\", ${ecut}, \$6}" ecut.$ecut.out >> calc-pressure.dat

done
gnuplot plot_ecutrho.gp
