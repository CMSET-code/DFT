#!/bin/bash
# Convergence test of ecutrho energy.

# Set cutoffs
for ecutrho in 120 180 240 300 360  420 480 540 600 ; do

cat > ecut.$ecutrho.in << EOF
&CONTROL
 calculation='scf',
 outdir='.',
 prefix='NaCl',
 pseudo_dir    = '/home/max/pseudo',
 verbosity='low',
 tprnfor=.true.,
 tstress=.true.,
/
&SYSTEM
 ibrav = 0
 A = 3.4
 nat = 2
 ntyp = 2
 ecutwfc =60,
 ecutrho = ${ecutrho},
 input_dft='pbe',
 occupations='smearing',
 smearing='mv',
 degauss=0.005d0,
/
&ELECTRONS
 conv_thr=1d-8,
 mixing_beta=0.7d0,
/
&IONS
 ion_dynamics='bfgs',
/
&CELL
 cell_dynamics='bfgs',
 press=0.d0,
 press_conv_thr=0.5d0,
/

CELL_PARAMETERS {alat}
 1.0 0.0 0.0
 0.0 1.0 0.0
 0.0 0.0 1.0

ATOMIC_SPECIES
 Cl 35.45150 cl_pbe_v1.4.uspp.F.UPF
 Na 22.98900 na_pbe_v1.5.uspp.F.UPF

ATOMIC_POSITIONS {crystal}
 Cl 0.5 0.5 0.5
 Na 0.0 0.0 0.0

K_POINTS {automatic}
 5 5 5 0 0 0
EOF

# Run SCF
mpirun -np 4 pw.x < ecut.$ecutrho.in > ecut.$ecutrho.out

# Extract total energy and append to convergence file
# Extract total stress
awk "/kbar/ {printf \"%d %s\n\", ${ecutrho}, \$6}" ecut.$ecutrho.out >> calc-ecutrho.dat

done

