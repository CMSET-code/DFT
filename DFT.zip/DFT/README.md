## README — Hands-On Tutorial: DFT with Quantum ESPRESSO

## Overview  
Welcome to this hands-on tutorial for performing "DFT calculations using Quantum ESPRESSO".
------------------------------------------------------------------
In this tutorial, we will: 
1. Convert a CIF file into a QE input file. 
2. Test convergence for three key parameters:
 — ecut
 — ecutrho
 — kpoints 
3. Perform a variable-cell relaxation ('vc-relax'). 
4. Compute projected density of states (pDOS). 
5. Compute the band structure.
------------------------------------------------------------------
Here is the recommended folder structure and the workflow for this tutorial:
/your-project-folder
|-- SCF/
|-- ecut/
|-- ecutrho/
|-- kpoint/
|-- vcrelax/
|-- DOS/
|-- BANDS/
└── README.md
